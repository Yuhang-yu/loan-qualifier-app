# this program displays the following floating-point number ina column with their decimal points aligned.
num1 = 127.899
num2 = 3456.148
num3 = 3.776
num4 = 264.821
num5 = 88.081
num6 = 799.999
print(f'{num1:7.2f}')
print(f'{num2:7.2f}')
print(f'{num3:7.2f}')
print(f'{num4:7.2f}')
print(f'{num5:7.2f}')
print(f'{num6:7.2f}')
