#assign a value to the salary variable
salary = 5000
#assign a value to the bunus variable
bonus = 300
#calculate the total pay by adding salary and bonus
pay = salary + bonus
#pay
print(pay)
print(f'your pay is {pay:.2f}yuan')
