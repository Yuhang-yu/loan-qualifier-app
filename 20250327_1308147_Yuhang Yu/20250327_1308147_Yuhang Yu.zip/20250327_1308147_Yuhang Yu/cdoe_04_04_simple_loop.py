print('I will display the odd numbers from 1 to 9')
for num in [1,3,5,7,9]:
    print(num)
print('-----')

for num in range (5):
    print(num)
print('-----')

for num in range(1,6):
    print(num)
print('-----')

for num in range(1,6,2):
    print(num)
print('-----')

for message in range(10):
    print("YULIA")
print('-----')

