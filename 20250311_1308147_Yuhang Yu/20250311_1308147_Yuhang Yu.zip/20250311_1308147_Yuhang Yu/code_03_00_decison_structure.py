sales = float(input("what your sales total?"))

if sales > 50000:
    bonus = 500
    commission_rate = 0.12
    print('You met your sales quota!')