x = 1
y = 0
z = 1
print(x >y)
print(x >x)
print(y >=x)
print(x >=y)
print(x !=y)
print(x !=z)
print(x ==z)
print(x ==y)